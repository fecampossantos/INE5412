#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main() {
    for(int i = 0; i < 4; i++){
        // loop pra criar 4 processos filho
        pid_t pid_fork;
        pid_fork = fork();

        if(pid_fork == 0){
            // processo filho
            pid_t pid_filho;
            pid_filho = getpid();
            printf("Processo filho %d\n", pid_filho);
            
            // previne o processo filho de rodar o wait embaixo
            exit(0);
        } else {
            // processo pai
            pid_t pid;
            pid = getpid();

            printf("Processo pai %d criou filho %d\n", pid, pid_fork);
        }
    }

    // processo pai espera pelos filhos
    for(int i = 0; i < 4; i++){
        wait(NULL);
    }

    return 0;
}