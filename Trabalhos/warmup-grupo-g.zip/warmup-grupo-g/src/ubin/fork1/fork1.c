#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

int main() {
    pid_t pid;
    pid = fork();

    if(pid >= 0){
        printf("Novo processo foi criado!\n");
        // processo foi criado
        if(pid != 0){
            // processo pai espera pelo filho
            wait(NULL);
        }
    } else {
        printf("\n! Não foi possível criar um processo.\n");
    }
    return 0;
}